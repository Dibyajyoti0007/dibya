#!/bin/bash

echo "Enter first number:"
read a

echo "Enter second number:"
read b

sum=$((a + b))

echo "The sum is: $sum"
